﻿using SolitarioMahjong;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfSolitarioMahjong
{
    /// <summary>
    /// Logica di interazione per Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        private int time = 5;
        private DispatcherTimer Timer;
        Mazzetto mazzetto = new Mazzetto();
        public Page1()
        {
            InitializeComponent();
            btnGiocaAncora.Visibility = Visibility.Hidden;
            btnSmettiDiGiocare.Visibility = Visibility.Hidden;
            Timer = new DispatcherTimer();
            Timer.Interval = new TimeSpan(0, 0, 1);
            Timer.Tick += Timer_Tick;
            SetTxtNCarte();
        }
        private void SetTxtNCarte()
        {
            txtNCarte1.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte2.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte3.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte4.Text = $"[{mazzetto.CarteMazzetto}]";

            txtNCarte5.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte6.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte7.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte8.Text = $"[{mazzetto.CarteMazzetto}]";

            txtNCarte9.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte10.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte11.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte12.Text = $"[{mazzetto.CarteMazzetto}]";

            txtNCarte13.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte14.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte15.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte16.Text = $"[{mazzetto.CarteMazzetto}]";
        }

        private void btnSelezionaCarte_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnGiocaAncora_Click(object sender, RoutedEventArgs e)
        {
            //reset partita
        }

        private void btnSmettiDiGiocare_Click(object sender, RoutedEventArgs e)
        {
            btnCarteNascoste();
            txtNCarteNascoste();
            btnGiocaAncora.Visibility = Visibility.Hidden;
            btnSmettiDiGiocare.Visibility = Visibility.Hidden;
            btnPrimaCarta.Visibility = Visibility.Hidden;
            btnSecondCarta.Visibility = Visibility.Hidden;
            txtPrimaCarta.Visibility = Visibility.Hidden;
            txtSecondaCarta.Visibility = Visibility.Hidden;
            btnSelezionaCarte.Visibility = Visibility.Hidden;

            txtFinMess.Visibility = Visibility.Visible;
            txtTempo.Visibility = Visibility.Visible;
            Timer.Start();
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (time > 0)
            {
                time--;
                txtTempo.Text = $"Chiusura applicazione in {time+1} secondi";
            }
            else
            {
                Timer.Stop();
                Application.Current.Shutdown();
            }
        }

        private void btnCarteNascoste()
        {
            btnCarta1.Visibility = Visibility.Hidden;
            btnCarta2.Visibility = Visibility.Hidden;
            btnCarta3.Visibility = Visibility.Hidden;
            btnCarta4.Visibility = Visibility.Hidden;
            btnCarta5.Visibility = Visibility.Hidden;
            btnCarta6.Visibility = Visibility.Hidden;
            btnCarta7.Visibility = Visibility.Hidden;
            btnCarta8.Visibility = Visibility.Hidden;
            btnCarta9.Visibility = Visibility.Hidden;
            btnCarta10.Visibility = Visibility.Hidden;
            btnCarta11.Visibility = Visibility.Hidden;
            btnCarta12.Visibility = Visibility.Hidden;
            btnCarta13.Visibility = Visibility.Hidden;
            btnCarta14.Visibility = Visibility.Hidden;
            btnCarta15.Visibility = Visibility.Hidden;
            btnCarta16.Visibility = Visibility.Hidden;
        }
        private void btnCarteVisibli()
        {
            btnCarta1.Visibility = Visibility.Visible;
            btnCarta2.Visibility = Visibility.Visible;
            btnCarta3.Visibility = Visibility.Visible;
            btnCarta4.Visibility = Visibility.Visible;
            btnCarta5.Visibility = Visibility.Visible;
            btnCarta6.Visibility = Visibility.Visible;
            btnCarta7.Visibility = Visibility.Visible;
            btnCarta8.Visibility = Visibility.Visible;
            btnCarta9.Visibility = Visibility.Visible;
            btnCarta10.Visibility = Visibility.Visible;
            btnCarta11.Visibility = Visibility.Visible;
            btnCarta12.Visibility = Visibility.Visible;
            btnCarta13.Visibility = Visibility.Visible;
            btnCarta14.Visibility = Visibility.Visible;
            btnCarta15.Visibility = Visibility.Visible;
            btnCarta16.Visibility = Visibility.Visible;
        }
        private void txtNCarteNascoste()
        {
            txtNCarte1.Visibility = Visibility.Hidden;
            txtNCarte2.Visibility = Visibility.Hidden;
            txtNCarte3.Visibility = Visibility.Hidden;
            txtNCarte4.Visibility = Visibility.Hidden;
            txtNCarte5.Visibility = Visibility.Hidden;
            txtNCarte6.Visibility = Visibility.Hidden;
            txtNCarte7.Visibility = Visibility.Hidden;
            txtNCarte8.Visibility = Visibility.Hidden;
            txtNCarte9.Visibility = Visibility.Hidden;
            txtNCarte10.Visibility = Visibility.Hidden;
            txtNCarte11.Visibility = Visibility.Hidden;
            txtNCarte12.Visibility = Visibility.Hidden;
            txtNCarte13.Visibility = Visibility.Hidden;
            txtNCarte14.Visibility = Visibility.Hidden;
            txtNCarte15.Visibility = Visibility.Hidden;
            txtNCarte16.Visibility = Visibility.Hidden;
        }
        private void txtNCarteVisibili()
        {
            txtNCarte1.Visibility = Visibility.Visible;
            txtNCarte2.Visibility = Visibility.Visible;
            txtNCarte3.Visibility = Visibility.Visible;
            txtNCarte4.Visibility = Visibility.Visible;
            txtNCarte5.Visibility = Visibility.Visible;
            txtNCarte6.Visibility = Visibility.Visible;
            txtNCarte7.Visibility = Visibility.Visible;
            txtNCarte8.Visibility = Visibility.Visible;
            txtNCarte9.Visibility = Visibility.Visible;
            txtNCarte10.Visibility = Visibility.Visible;
            txtNCarte11.Visibility = Visibility.Visible;
            txtNCarte12.Visibility = Visibility.Visible;
            txtNCarte13.Visibility = Visibility.Visible;
            txtNCarte14.Visibility = Visibility.Visible;
            txtNCarte15.Visibility = Visibility.Visible;
            txtNCarte16.Visibility = Visibility.Visible;
        }
    }
}
