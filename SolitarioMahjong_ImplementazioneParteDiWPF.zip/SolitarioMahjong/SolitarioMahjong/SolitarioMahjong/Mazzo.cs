﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolitarioMahjong
{
    public class Mazzo
    {
        private Carta[] _carte;
        private int _indice;

        public Carta[] Carte
        {
            get { return _carte; }
            set
            {

            }
        }

        public int Indice
        {
            get { return _indice; }
            set
            {

            }
        }

        public Mazzo()
        {
            _carte = new Carta[40];
            _indice = 0;
            InizializzaMazzo();
        }

        private void InizializzaMazzo()
        {
            int i = 0;
            for (int seme = 1; seme <= 4; seme++)
            {
                for (int valore = 1; valore <= 10; valore++)
                {
                    _carte[i] = new Carta(valore, (Seme)seme);
                    i++;
                }
            }
        }

        public void MescolaMazzo()
        {
            if (_indice != 0) throw new Exception("non puoi mescolare il mazzo se non ha tutte le carte");
            Random random = new Random();
            int pos;
            Carta cartaDaScambiare;
            for (int j = 0; j < 1000; j++)
            {
                for (int i = 0; i < _carte.Length; i++)
                {
                    pos = random.Next(0, _carte.Length);
                    cartaDaScambiare = _carte[pos];
                    _carte[pos] = _carte[i];
                    _carte[i] = cartaDaScambiare;
                }
            }

        }
    }
}
