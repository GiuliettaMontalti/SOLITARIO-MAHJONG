﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolitarioMahjong
{
    public class Mazzetto
    {
        private List<Carta> _carteMazzetto;

        public List<Carta> CarteMazzetto
        {
            get { return _carteMazzetto; }
            set
            {

            }
        }

        public Mazzetto()
        {

        }

        public int ContaCarteMazzetto()
        {
            return _carteMazzetto.Count;
        }


    }
}
