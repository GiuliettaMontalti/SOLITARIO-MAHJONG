﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfSolitarioMahjong
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Page1 page = new Page1();
        public MainWindow()
        {
            InitializeComponent();
            lbRegoleGioco.Visibility = Visibility.Hidden;
            txtRegole.Visibility = Visibility.Hidden;
        }

        private void btnRegole_Click(object sender, RoutedEventArgs e)
        {
            btnRegole.Visibility = Visibility.Collapsed;
            txtRegole.Visibility = Visibility.Visible;
        }

        private void boxNome_GotFocus(object sender, RoutedEventArgs e)
        {
            if (boxNome.Text == "Inserire nome") { boxNome.Text = ""; }
            boxNome.Foreground.Opacity = 100;
        }

        private void btnInizio_Click(object sender, RoutedEventArgs e)
        {
            bool continua = true;
            try
            { 
                string nome = boxNome.Text;
                if (nome == "Inserire nome") throw new Exception("inserire nome valido");
            }catch (Exception ex) { txtErr.Text = ex.Message; continua = false; }
            Page page1 = new Page1();
            Content = page1;
        }
    }
}
