﻿using SolitarioMahjong;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfSolitarioMahjong
{
    /// <summary>
    /// Logica di interazione per Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        Mazzetto mazzetto = new Mazzetto();
        public Page1()
        {
            InitializeComponent();
            SetTxtNCarte();
        }
        private void SetTxtNCarte()
        {
            txtNCarte1.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte2.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte3.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte4.Text = $"[{mazzetto.CarteMazzetto}]";

            txtNCarte5.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte6.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte7.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte8.Text = $"[{mazzetto.CarteMazzetto}]";

            txtNCarte9.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte10.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte11.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte12.Text = $"[{mazzetto.CarteMazzetto}]";

            txtNCarte13.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte14.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte15.Text = $"[{mazzetto.CarteMazzetto}]";
            txtNCarte16.Text = $"[{mazzetto.CarteMazzetto}]";
        }

        private void btnSelezionaCarte_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnGiocaAncora_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSmettiDiGiocare_Click(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
